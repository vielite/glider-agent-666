#!/usr/bin/env python3
"""
Simple RAG Bot for API Documentation
Uses Google Gemini 2.5 Flash for answering questions
"""

import os
import re
import json
from collections import defaultdict
import requests


class SimpleRAG:
    """Simple TF-IDF based document retrieval system"""
    
    def __init__(self, documents):
        self.documents = documents
        self.index = self._build_index()
    
    def _build_index(self):
        """Build a simple word frequency index"""
        index = {}
        
        for idx, doc in enumerate(self.documents):
            words = re.findall(r'\w+', doc['content'].lower())
            word_freq = defaultdict(int)
            
            for word in words:
                if len(word) > 2:  # Skip very short words
                    word_freq[word] += 1
            
            index[idx] = dict(word_freq)
        
        return index
    
    def search(self, query, top_k=3):
        """Search for relevant documents based on query"""
        query_words = [w.lower() for w in re.findall(r'\w+', query) if len(w) > 2]
        scores = []
        
        for idx, doc in enumerate(self.documents):
            word_freq = self.index[idx]
            score = 0
            
            # Calculate relevance score
            for word in query_words:
                if word in word_freq:
                    score += word_freq[word]
            
            # Boost if query words in title
            title_lower = doc['title'].lower()
            for word in query_words:
                if word in title_lower:
                    score += 10
            
            if score > 0:
                scores.append((score, idx, doc))
        
        # Sort by score descending
        scores.sort(reverse=True, key=lambda x: x[0])
        
        return [doc for _, _, doc in scores[:top_k]]


def parse_documents(markdown_text):
    """Parse markdown documentation into chunks"""
    chunks = []
    sections = re.split(r'^---$', markdown_text, flags=re.MULTILINE)
    
    for i, section in enumerate(sections):
        section = section.strip()
        if not section:
            continue
        
        # Extract title from heading
        title_match = re.search(r'^#\s+(.+)$', section, re.MULTILINE)
        title = title_match.group(1) if title_match else f"Section {i}"
        
        chunks.append({
            'title': title,
            'content': section,
            'id': i
        })
    
    return chunks


def query_gemini(prompt, api_key):
    """Query Google Gemini API"""
    url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"
    
    headers = {
        "Content-Type": "application/json"
    }
    
    data = {
        "contents": [{
            "parts": [{
                "text": prompt
            }]
        }]
    }
    
    response = requests.post(
        f"{url}?key={api_key}",
        headers=headers,
        json=data
    )
    
    if response.status_code != 200:
        raise Exception(f"API Error: {response.status_code} - {response.text}")
    
    result = response.json()
    
    # Extract text from response
    try:
        text = result['candidates'][0]['content']['parts'][0]['text']
        return text
    except (KeyError, IndexError) as e:
        raise Exception(f"Unexpected response format: {e}")


def main():
    print("=" * 70)
    print("🤖 RAG Bot - API Documentation Assistant")
    print("=" * 70)
    print()
    
    # Get API key
    api_key = os.environ.get('GEMINI_API_KEY')
    if not api_key:
        print("⚠️  GEMINI_API_KEY not found in environment variables!")
        api_key = input("Please enter your Gemini API key: ").strip()
        if not api_key:
            print("❌ No API key provided. Exiting.")
            return
    
    print("📚 Loading documentation...")
    
    # Load documentation
    try:
        with open('/mnt/user-data/uploads/api-docs-merged.md', 'r', encoding='utf-8') as f:
            doc_text = f.read()
    except FileNotFoundError:
        print("❌ Could not find api-docs-merged.md")
        print("Please ensure the file is in the correct location.")
        return
    
    # Parse and index documents
    print("🔍 Indexing documentation...")
    documents = parse_documents(doc_text)
    rag = SimpleRAG(documents)
    
    print(f"✅ Indexed {len(documents)} documentation sections")
    print()
    print("💡 Ask questions about the API documentation")
    print("   Type 'quit' or 'exit' to end the session")
    print("=" * 70)
    print()
    
    # Main chat loop
    while True:
        try:
            # Get user input
            user_input = input("\n🧑 You: ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ['quit', 'exit', 'q']:
                print("\n👋 Goodbye!")
                break
            
            # Retrieve relevant documents
            print("\n🔎 Searching documentation...")
            relevant_docs = rag.search(user_input, top_k=3)
            
            if not relevant_docs:
                print("❌ No relevant documentation found for your query.")
                continue
            
            # Build context
            context = "\n\n---\n\n".join([
                f"[Document: {doc['title']}]\n{doc['content']}"
                for doc in relevant_docs
            ])
            
            # Create prompt for Gemini
            prompt = f"""You are a helpful assistant that answers questions based on API documentation.

Here is the relevant documentation context:

{context}

User question: {user_input}

Please answer the question based on the provided documentation. If the answer isn't in the documentation, say so. Be concise and helpful. Format your response in a clear, readable way."""
            
            # Query Gemini
            print("🤖 Generating answer...")
            try:
                answer = query_gemini(prompt, api_key)
                
                print("\n" + "=" * 70)
                print("🤖 Assistant:")
                print("=" * 70)
                print(answer)
                print()
                
                # Show sources
                print("📑 Sources used:")
                for doc in relevant_docs:
                    print(f"   • {doc['title']}")
                
            except Exception as e:
                print(f"\n❌ Error querying Gemini API: {e}")
                print("Please check your API key and internet connection.")
        
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Unexpected error: {e}")


if __name__ == "__main__":
    main()
