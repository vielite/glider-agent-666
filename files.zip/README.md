# RAG Bot - Command Line API Documentation Assistant

A simple command-line RAG (Retrieval-Augmented Generation) bot that answers questions about your API documentation using Google Gemini 2.5 Flash.

## Features

- 📚 Indexes API documentation for fast retrieval
- 🔍 TF-IDF based similarity search
- 🤖 Uses Google Gemini 2.5 Flash for intelligent answers
- 💻 Simple command-line interface
- 📑 Shows source documents used for each answer

## Prerequisites

- Python 3.7+
- `requests` library
- Google Gemini API key

## Installation

1. Install required Python package:
```bash
pip install requests
```

2. Get your Gemini API key:
   - Go to https://aistudio.google.com/app/apikey
   - Create or sign in to your Google account
   - Generate an API key

3. Set your API key as an environment variable:
```bash
export GEMINI_API_KEY="your-api-key-here"
```

Or on Windows:
```cmd
set GEMINI_API_KEY=your-api-key-here
```

## Usage

Run the bot:
```bash
python3 rag_bot.py
```

Or if you made it executable:
```bash
./rag_bot.py
```

The bot will:
1. Load and index the API documentation
2. Start an interactive chat session
3. Answer your questions based on the documentation

### Example Session

```
======================================================================
🤖 RAG Bot - API Documentation Assistant
======================================================================

📚 Loading documentation...
🔍 Indexing documentation...
✅ Indexed 234 documentation sections

💡 Ask questions about the API documentation
   Type 'quit' or 'exit' to end the session
======================================================================

🧑 You: How do I use LocalVariable?

🔎 Searching documentation...
🤖 Generating answer...

======================================================================
🤖 Assistant:
======================================================================
LocalVariable is used to work with local variables in functions...
[detailed answer here]

📑 Sources used:
   • LocalVariable.memory_property
   • LocalVariable.get_parent()

🧑 You: quit

👋 Goodbye!
```

## Commands

- Type your question and press Enter
- Type `quit`, `exit`, or `q` to exit
- Press `Ctrl+C` to exit at any time

## How It Works

1. **Document Loading**: Parses the markdown documentation into searchable chunks
2. **Indexing**: Builds a TF-IDF index for fast similarity search
3. **Retrieval**: When you ask a question, finds the 3 most relevant documentation sections
4. **Generation**: Sends the question + context to Gemini API
5. **Response**: Displays the answer with source citations

## Configuration

You can modify these parameters in the code:

- `top_k=3` in the search method - Number of documents to retrieve
- Model: Currently uses `gemini-2.0-flash-exp` - You can change this to other Gemini models

## Troubleshooting

**"GEMINI_API_KEY not found"**
- Make sure you've set the environment variable
- Or enter it when prompted

**"API Error: 400"**
- Check that your API key is valid
- Ensure you have API quota remaining

**"Could not find api-docs-merged.md"**
- Make sure the documentation file is in the correct location
- Update the file path in the code if needed

## File Structure

```
rag_bot.py              # Main script
api-docs-merged.md      # Your API documentation
README.md               # This file
```

## License

MIT License - Feel free to modify and use as needed!
